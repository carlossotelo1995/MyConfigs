---------------------------
-- Argentina awesome theme --
---------------------------

local theme_assets = require("beautiful.theme_assets")
local xresources = require("beautiful.xresources")
local dpi = xresources.apply_dpi

local gfs = require("gears.filesystem")
local themes_path = "~/.config/awesome/themes/"

local theme = {}

theme.font          = "Inconsolata Bold 14"
-- Colors
local invColors = true --Invert colors of the Theme
if invColors == true then
    white = "#2255FF"
    blue = "#FFFFFF"
    darkblue = "#AAAAAA"  
    lightblue = blue
    black = "#000000"
    grey = "#AAAAAA"
else
    white = "#FFFFFF"
    blue = "#2255FF"
    darkblue = "#2255BB"
    lightblue = "#0099FF"
    black = "#000000"
    grey = "#AAAAAA"
end   

theme.bg_normal     = blue
theme.bg_focus      = lightblue
theme.bg_urgent     = white
theme.bg_minimize   = darkblue
theme.bg_systray    = theme.bg_normal

theme.fg_normal     = white 
theme.fg_focus      = white
theme.fg_urgent     = white
theme.fg_minimize   = grey

theme.useless_gap   = dpi(0)
theme.border_width  = dpi(3)
theme.border_normal = blue
theme.border_focus  = white
theme.border_marked = "#FF0000"

-- There are other variable sets
-- overriding the default one when
-- defined, the sets are:
-- taglist_[bg|fg]_[focus|urgent|occupied|empty|volatile]
theme.taglist_fg_focus = blue
theme.taglist_bg_focus = white
--theme.taglist_bg_occupied = darkblue
--theme.taglist_fg_occupied = grey
-- tasklist_[bg|fg]_[focus|urgent]
if invColors == true then
    theme.tasklist_bg_focus = white
    theme.tasklist_fg_focus = blue
end
-- titlebar_[bg|fg]_[normal|focus]
if invColors == true then
    theme.titlebar_fg_focus = blue
    theme.titlebar_bg_focus = white
end
-- tooltip_[font|opacity|fg_color|bg_color|border_width|border_color]
-- mouse_finder_[color|timeout|animate_timeout|radius|factor]
-- prompt_[fg|bg|fg_cursor|bg_cursor|font]
-- hotkeys_[bg|fg|border_width|border_color|shape|opacity|modifiers_fg|label_bg|label_fg|group_margin|font|description_font]
-- Example:
--theme.taglist_bg_focus = "#ff0000"

-- Generate taglist squares:
local taglist_square_size = dpi(4)
theme.taglist_squares_sel = theme_assets.taglist_squares_sel(
    taglist_square_size, blue
)
theme.taglist_squares_unsel = theme_assets.taglist_squares_unsel(
    taglist_square_size, white
)

-- Variables set for theming notifications:
-- notification_font
-- notification_[bg|fg]
theme.notification_bg = blue
theme.notification_fg = white
-- notification_[width|height|margin]
-- notification_[border_color|border_width|shape|opacity]

-- Variables set for theming the menu:
-- menu_[bg|fg]_[normal|focus]
-- menu_[border_color|border_width]

--INVERTED COLORS--------
if invColors == true then
    theme.menu_bg_focus = white
    theme.menu_fg_focus = blue
end
-----------------------------
-------------------------------

theme.menu_submenu_icon = themes_path.."argentina/submenu.png"
theme.menu_height = dpi(15)
theme.menu_width  = dpi(100)

-- You can add as many variables as
-- you wish and access them by using
-- beautiful.variable in your rc.lua
--theme.bg_widget = "#cc0000"

-- Define the image to load
if invColors == true then
    theme.titlebar_close_button_normal = themes_path.."argentina/titlebar/inverted/close_normal.png"
    theme.titlebar_close_button_focus  = themes_path.."/argentina/titlebar/inverted/close_focus.png"

    theme.titlebar_minimize_button_normal = themes_path.."argentina/titlebar/inverted/minimize_normal.png"
    theme.titlebar_minimize_button_focus  = themes_path.."argentina/titlebar/inverted/minimize_focus.png"

    theme.titlebar_ontop_button_normal_inactive = themes_path.."argentina/titlebar/inverted/ontop_normal_inactive.png"
    theme.titlebar_ontop_button_focus_inactive  = themes_path.."argentina/titlebar/inverted/ontop_focus_inactive.png"
    theme.titlebar_ontop_button_normal_active = themes_path.."argentina/titlebar/inverted/ontop_normal_active.png"
    theme.titlebar_ontop_button_focus_active  = themes_path.."argentina/titlebar/inverted/ontop_focus_active.png"

    theme.titlebar_sticky_button_normal_inactive = themes_path.."argentina/titlebar/inverted/sticky_normal_inactive.png"
    theme.titlebar_sticky_button_focus_inactive  = themes_path.."argentina/titlebar/inverted/sticky_focus_inactive.png"
    theme.titlebar_sticky_button_normal_active = themes_path.."argentina/titlebar/inverted/sticky_normal_active.png"
    theme.titlebar_sticky_button_focus_active  = themes_path.."argentina/titlebar/inverted/sticky_focus_active.png"

    theme.titlebar_floating_button_normal_inactive = themes_path.."argentina/titlebar/inverted/floating_normal_inactive.png"
    theme.titlebar_floating_button_focus_inactive  = themes_path.."argentina/titlebar/inverted/floating_focus_inactive.png"
    theme.titlebar_floating_button_normal_active = themes_path.."argentina/titlebar/inverted/floating_normal_active.png"
    theme.titlebar_floating_button_focus_active  = themes_path.."argentina/titlebar/inverted/floating_focus_active.png"

    theme.titlebar_maximized_button_normal_inactive = themes_path.."argentina/titlebar/inverted/maximized_normal_inactive.png"
    theme.titlebar_maximized_button_focus_inactive  = themes_path.."argentina/titlebar/inverted/maximized_focus_inactive.png"
    theme.titlebar_maximized_button_normal_active = themes_path.."argentina/titlebar/inverted/maximized_normal_active.png"
    theme.titlebar_maximized_button_focus_active  = themes_path.."argentina/titlebar/inverted/maximized_focus_active.png"
else

    theme.titlebar_close_button_normal = themes_path.."argentina/titlebar/close_normal.png"
    theme.titlebar_close_button_focus  = themes_path.."argentina/titlebar/close_focus.png"

    theme.titlebar_minimize_button_normal = themes_path.."argentina/titlebar/minimize_normal.png"
    theme.titlebar_minimize_button_focus  = themes_path.."argentina/titlebar/minimize_focus.png"

    theme.titlebar_ontop_button_normal_inactive = themes_path.."argentina/titlebar/ontop_normal_inactive.png"
    theme.titlebar_ontop_button_focus_inactive  = themes_path.."argentina/titlebar/ontop_focus_inactive.png"
    theme.titlebar_ontop_button_normal_active = themes_path.."argentina/titlebar/ontop_normal_active.png"
    theme.titlebar_ontop_button_focus_active  = themes_path.."argentina/titlebar/ontop_focus_active.png"

    theme.titlebar_sticky_button_normal_inactive = themes_path.."argentina/titlebar/sticky_normal_inactive.png"
    theme.titlebar_sticky_button_focus_inactive  = themes_path.."argentina/titlebar/sticky_focus_inactive.png"
    theme.titlebar_sticky_button_normal_active = themes_path.."argentina/titlebar/sticky_normal_active.png"
    theme.titlebar_sticky_button_focus_active  = themes_path.."argentina/titlebar/sticky_focus_active.png"

    theme.titlebar_floating_button_normal_inactive = themes_path.."argentina/titlebar/floating_normal_inactive.png"
    theme.titlebar_floating_button_focus_inactive  = themes_path.."argentina/titlebar/floating_focus_inactive.png"
    theme.titlebar_floating_button_normal_active = themes_path.."argentina/titlebar/floating_normal_active.png"
    theme.titlebar_floating_button_focus_active  = themes_path.."argentina/titlebar/floating_focus_active.png"

    theme.titlebar_maximized_button_normal_inactive = themes_path.."argentina/titlebar/maximized_normal_inactive.png"
    theme.titlebar_maximized_button_focus_inactive  = themes_path.."argentina/titlebar/maximized_focus_inactive.png"
    theme.titlebar_maximized_button_normal_active = themes_path.."argentina/titlebar/maximized_normal_active.png"
    theme.titlebar_maximized_button_focus_active  = themes_path.."argentina/titlebar/maximized_focus_active.png"
end

theme.wallpaper = "~/Pictures/wallpapers/Material/1.jpg" 


-- You can use your own layout icons like this:
if invColors == true then
    theme.layout_fairh = themes_path.."argentina/layouts/inverted/fairhw.png"
    theme.layout_fairv = themes_path.."argentina/layouts/inverted/fairvw.png"
    theme.layout_floating  = themes_path.."argentina/layouts/inverted/floatingw.png"
    theme.layout_magnifier = themes_path.."argentina/layouts/inverted/magnifierw.png"
    theme.layout_max = themes_path.."argentina/layouts/inverted/maxw.png"
    theme.layout_fullscreen = themes_path.."argentina/layouts/inverted/fullscreenw.png"
    theme.layout_tilebottom = themes_path.."argentina/layouts/inverted/tilebottomw.png"
    theme.layout_tileleft   = themes_path.."argentina/layouts/inverted/tileleftw.png"
    theme.layout_tile = themes_path.."argentina/layouts/inverted/tilew.png"
    theme.layout_tiletop = themes_path.."argentina/layouts/inverted/tiletopw.png"
    theme.layout_spiral  = themes_path.."argentina/layouts/inverted/spiralw.png"
    theme.layout_dwindle = themes_path.."argentina/layouts/inverted/dwindlew.png"
    theme.layout_cornernw = themes_path.."argentina/layouts/inverted/cornernww.png"
    theme.layout_cornerne = themes_path.."argentina/layouts/inverted/cornernew.png"
    theme.layout_cornersw = themes_path.."argentina/layouts/inverted/cornersww.png"
    theme.layout_cornerse = themes_path.."argentina/layouts/inverted/cornersew.png"
else
    theme.layout_fairh = themes_path.."argentina/layouts/fairhw.png"
    theme.layout_fairv = themes_path.."argentina/layouts/fairvw.png"
    theme.layout_floating  = themes_path.."argentina/layouts/floatingw.png"
    theme.layout_magnifier = themes_path.."argentina/layouts/magnifierw.png"
    theme.layout_max = themes_path.."argentina/layouts/maxw.png"
    theme.layout_fullscreen = themes_path.."argentina/layouts/fullscreenw.png"
    theme.layout_tilebottom = themes_path.."argentina/layouts/tilebottomw.png"
    theme.layout_tileleft   = themes_path.."argentina/layouts/tileleftw.png"
    theme.layout_tile = themes_path.."argentina/layouts/tilew.png"
    theme.layout_tiletop = themes_path.."argentina/layouts/tiletopw.png"
    theme.layout_spiral  = themes_path.."argentina/layouts/spiralw.png"
    theme.layout_dwindle = themes_path.."argentina/layouts/dwindlew.png"
    theme.layout_cornernw = themes_path.."argentina/layouts/cornernww.png"
    theme.layout_cornerne = themes_path.."argentina/layouts/cornernew.png"
    theme.layout_cornersw = themes_path.."argentina/layouts/cornersww.png"
    theme.layout_cornerse = themes_path.."argentina/layouts/cornersew.png"
end
-- Generate Awesome icon:
theme.awesome_icon = theme_assets.awesome_icon(
    theme.menu_height, white, blue
)

-- Define the icon theme for application icons. If not set then the icons
-- from /usr/share/icons and /usr/share/icons/hicolor will be used.
theme.icon_theme = nil

return theme

-- vim: filetype=lua:expandtab:shiftwidth=4:tabstop=8:softtabstop=4:textwidth=80

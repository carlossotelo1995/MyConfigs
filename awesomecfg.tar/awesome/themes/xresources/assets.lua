require("gears.debug").deprecate("Use beautiful.theme_assets instead.", {raw=true})
return require("beautiful.theme_assets")
